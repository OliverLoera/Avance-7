<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Felcor Transportes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <div class="logo">🚐 Felcor</div>
        <nav>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="destinos.html">Destinos</a></li>
                <li><a href="frontend.html">Vehículos</a></li>
                <li><a href="#">Contacto</a></li>
            </ul>
        </nav>
    </header>

    <section class="hero">
        <div class="carousel">
            <img src="imagenes/suburban.png" alt="Slide 1" class="active">
            <img src="imagenes/camion.jpg" alt="Slide 2">
            <img src="imagenes/Playa.jpg" alt="Slide 3">
        </div>
    </section>

    <section class="bienvenida">
        <h1>Bienvenido a Felcor Transportes</h1>
        <p>Somos tu mejor opción para viajar cómodo, seguro y a tiempo. Explora nuestros destinos y elige el vehículo ideal para tu viaje.</p>
    </section>

    <section class="preview">
        <h2>Nuestros vehículos</h2>
        <div class="vehiculos">
            <div class="vehiculo-card">
                <img src="imagenes/Van.png" alt="Van 1">
                <h3>Van ejecutiva</h3>
                <p>Ideal para grupos pequeños. Comodidad y eficiencia.</p>
            </div>
            <div class="vehiculo-card">
                <img src="imagenes/Autobus.png" alt="Bus 1">
                <h3>Autobús turístico</h3>
                <p>Perfecto para excursiones largas. Totalmente equipado.</p>
            </div>
        </div>
    </section>

    <footer>
        <p>&copy; 2025 Felcor Transportes. Todos los derechos reservados.</p>
        <p><a href="#">Política de privacidad</a> | <a href="#">Términos y condiciones</a></p>
    </footer>

    <script>
        // Carrusel simple
        let current = 0;
        const slides = document.querySelectorAll(".carousel img");

        setInterval(() => {
            slides[current].classList.remove("active");
            current = (current + 1) % slides.length;
            slides[current].classList.add("active");
        }, 3000);
    </script>

</body>
</html>
